from openai import OpenAI
from .logger import logger
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("NVIDIA_API_KEY")
client = OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key=api_key)

def route_user_intent(user_prompt):
    system_prompt = """Classify the user request into one of the following categories:
    - summarize
    - table_query
    - visualize
    - rag

    Use:
    - summarize: when the user asks to summarize the entire document.
    - table_query: when the user asks a question involving data extraction from tabular data.
    - visualize: when the user asks for any form of chart/graph/plot.
    - rag: for any specific question that doesn’t match the above.

    Only return one of the above category names.
    """

    try:
        response = client.chat.completions.create(
            model="nvidia/llama-3.3-nemotron-super-49b-v1",  # Replace with your LLM
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.0
        )
        return response.choices[0].message.content.strip().lower()
    except openai.RateLimitError as e:  # Catch directly from openai
        logger.error(f"NVIDIA API Rate Limit Exceeded: {e}")
        return "Error: The intent classification service is experiencing high demand. Please try your query again later or rephrase it."
    except Exception as e:
        logger.error(f"Error during intent routing: {e}")
        return "Error: Could not determine the intent of your query. Please try again."