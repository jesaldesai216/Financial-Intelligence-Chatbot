import matplotlib.pyplot as plt
import seaborn as sns
from openai import OpenAI, RateLimitError
from .logger import logger
from dotenv import load_dotenv
import os
import pandas as pd
import io
import base64
import re
import json  # Import the json library

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")  # Changed environment variable name
client = OpenAI(api_key=api_key)  # Using default OpenAI base URL

def plot_chart_from_prompt(df, user_prompt):
    try:
        plot_type = None
        x_col = None
        y_col = None
        color_col = None
        size_col = None
        filters = {}

        # 1. Send the user prompt and DataFrame column names to the LLM
        columns = df.columns.tolist()
        prompt = f"""
            User wants to plot a chart based on the following data and instruction:
            Data Columns: {columns}
            Instruction: {user_prompt}

            Identify the following:
            - plot_type (bar, line, scatter, pie, or null if not specified)
            - y_column (the primary column to be plotted on the y-axis or used for values in a pie chart)
            - x_column (the column to be plotted on the x-axis, used for categories in a bar or pie chart, or for the independent variable in line/scatter plots; can be null if not applicable)
            - color_column (an optional column to use for coloring data points or segments)
            - size_column (an optional column to use for the size of data points in a scatter plot)
            - filters (a dictionary of column names and values to filter by, or an empty dictionary if no filters are specified).

            Return your response as a JSON object. If you are unsure about any field, leave it as null or an empty dictionary.
        """

        response = client.chat.completions.create(
            model="gpt-3.5-turbo-0125",  # A generally capable and cost-effective model
            messages=[
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )

        try:
            llm_output = response.choices[0].message.content
            parsed_output = json.loads(llm_output)

            plot_type = parsed_output.get("plot_type")
            y_col = parsed_output.get("y_column")
            x_col = parsed_output.get("x_column")
            color_col = parsed_output.get("color_column")
            size_col = parsed_output.get("size_column")
            filters = parsed_output.get("filters", {})

        except json.JSONDecodeError as e:
            logger.error(f"Error decoding LLM response for chart: {e}, Response: {llm_output}")
            return "Could not understand the chart request."

        # 2. Apply filters to the DataFrame
        filtered_df = df.copy()
        for col, value in filters.items():
            if col in filtered_df.columns:
                filtered_df = filtered_df[filtered_df[col].astype(str) == value]
            else:
                logger.warning(f"Filter column '{col}' not found in DataFrame.")

        # 3. Generate the plot based on LLM output
        if plot_type and y_col in filtered_df.columns:
            plt.figure(figsize=(10, 6))
            if plot_type == 'bar' and x_col in filtered_df.columns:
                sns.barplot(data=filtered_df, x=x_col, y=y_col, hue=color_col)
                plt.xlabel(x_col)
                plt.ylabel(y_col)
                plt.title(f'Bar Chart of {y_col} by {x_col} ({", ".join([f"{k}={v}" for k, v in filters.items()])})')
            elif plot_type == 'line' and x_col in filtered_df.columns:
                sns.lineplot(data=filtered_df, x=x_col, y=y_col, hue=color_col)
                plt.xlabel(x_col)
                plt.ylabel(y_col)
                plt.title(f'Line Chart of {y_col} over {x_col} ({", ".join([f"{k}={v}" for k, v in filters.items()])})')
            elif plot_type == 'scatter' and x_col in filtered_df.columns:
                sns.scatterplot(data=filtered_df, x=x_col, y=y_col, hue=color_col, size=size_col)
                plt.xlabel(x_col)
                plt.ylabel(y_col)
                plt.title(f'Scatter Plot of {y_col} vs {x_col} ({", ".join([f"{k}={v}" for k, v in filters.items()])})')
            elif plot_type == 'pie' and x_col in filtered_df.columns:
                plt.pie(filtered_df[y_col], labels=filtered_df[x_col], autopct='%1.1f%%', startangle=140)
                plt.title(f'Pie Chart of {y_col} Distribution by {x_col} ({", ".join([f"{k}={v}" for k, v in filters.items()])})')
                plt.axis('equal')
            elif plot_type == 'bar': # Simple bar of a single column
                plt.bar(filtered_df.index, filtered_df[y_col], color=sns.color_palette()[0]) # Default color
                plt.xlabel("Index")
                plt.ylabel(y_col)
                plt.title(f'Bar Chart of {y_col} ({", ".join([f"{k}={v}" for k, v in filters.items()])})')
            else:
                return "Could not determine the chart type or necessary columns from your request."

            img_buf = io.BytesIO()
            plt.savefig(img_buf, format='png')
            img_buf.seek(0)
            img_base64 = base64.b64encode(img_buf.read()).decode('utf-8')
            plt.close()
            return f'<img src="data:image/png;base64,{img_base64}" alt="Generated Chart">'
        else:
            return "Could not identify the column to plot from your request."

    except RateLimitError as e:
        logger.error(f"OpenAI API Rate Limit Exceeded during chart generation: {e}")
        return "Error: The chart generation service is experiencing high demand. Please try again later."
    except Exception as e:
        logger.error(f"Error generating chart: {e}")
        return f"Error generating chart: {e}"

def _encode_plot_to_base64():
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    encoded = base64.b64encode(image_png).decode('utf-8')
    plt.close()
    return f"data:image/png;base64,{encoded}"

def generate_bar_chart(df, instruction):
    try:
        numeric_df = df.select_dtypes(include='number')
        if numeric_df.empty:
            return "Error: No numeric data available to plot."
        ax = numeric_df.plot(kind='bar', figsize=(10, 6))
        plt.title("Bar Chart")
        plt.tight_layout()
        return _encode_plot_to_base64()
    except RateLimitError as e:
        logger.error(f"OpenAI API Rate Limit Exceeded during bar chart generation: {e}")
        return "Error: The chart generation service is experiencing high demand. Please try again later."
    except Exception as e:
        return f"Error generating bar chart: {e}"

def generate_line_chart(df, instruction):
    try:
        # Try to infer x and y columns from the instruction
        x_col = None
        y_col = None
        for col in df.columns:
            if "time" in col.lower() or "date" in col.lower() or "year" in col.lower() or "quarter" in col.lower() or col.lower() in instruction.lower() and x_col is None:
                x_col = col
            elif pd.api.types.is_numeric_dtype(df[col]) and col.lower() in instruction.lower() and y_col is None:
                y_col = col

        if x_col and y_col:
            plt.figure(figsize=(10, 6))
            plt.plot(df[x_col], df[y_col])
            plt.xlabel(x_col)
            plt.ylabel(y_col)
            plt.title(f"Line Chart of {y_col} over {x_col}")
            plt.grid(True)
            plt.tight_layout()
            return _encode_plot_to_base64()
        else:
            return "Error: Could not identify suitable columns for a line chart based on the instruction."
    except RateLimitError as e:
        logger.error(f"OpenAI API Rate Limit Exceeded during line chart generation: {e}")
        return "Error: The chart generation service is experiencing high demand. Please try again later."
    except Exception as e:
        return f"Error generating line chart: {e}"

def generate_scatter_plot(df, instruction):
    try:
        if len(df.columns) < 2:
            return "Error: Scatter plot requires at least two columns."
        # Try to infer x and y columns from the instruction (simplistic approach)
        x_col = df.columns[0]
        y_col = None
        for col in df.columns[1:]:
            if pd.api.types.is_numeric_dtype(df[col]) and col.lower() in instruction.lower():
                y_col = col
                break
        if y_col:
            plt.figure(figsize=(10, 6))
            sns.scatterplot(data=df, x=x_col, y=y_col)
            plt.title(f"Scatter Plot of {y_col} vs {x_col}")
            plt.tight_layout()
            return _encode_plot_to_base64()
        else:
            return "Error: Could not identify suitable columns for a scatter plot based on the instruction."
    except RateLimitError as e:
        logger.error(f"OpenAI API Rate Limit Exceeded during scatter plot generation: {e}")
        return "Error: The chart generation service is experiencing high demand. Please try again later."
    except Exception as e:
        return f"Error generating scatter plot: {e}"