import os
import time
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.summarize import load_summarize_chain
from langchain_openai import OpenAI
from dotenv import load_dotenv
from .logger import logger  # Assuming you have a logger
import openai

load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")
llm = OpenAI(api_key=openai_api_key)

def summarize_large_text(text, chunk_size=3000, chunk_overlap=200, chain_type="map_reduce", map_prompt=None, combine_prompt=None, max_retries=3, retry_delay=5):
    """
    Summarizes a large text with rate limit handling.
    """
    try:
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        docs = text_splitter.create_documents([text])
        logger.info(f"Split text into {len(docs)} chunks.")

        if chain_type == "map_reduce":
            chain = load_summarize_chain(llm, chain_type=chain_type, map_prompt=map_prompt, combine_prompt=combine_prompt)
        else:
            chain = load_summarize_chain(llm, chain_type=chain_type)

        for attempt in range(max_retries + 1):
            try:
                summary = chain.run(docs)
                logger.info("Successfully generated summary for large text.")
                return summary
            except openai.error.RateLimitError as e:
                logger.warning(f"Rate limit error encountered (attempt {attempt + 1}/{max_retries + 1}): {e}")
                if attempt < max_retries:
                    time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                else:
                    logger.error("Max retries reached. Rate limit error still occurring.")
                    raise
            except Exception as e:
                logger.error(f"Error summarizing large text: {e}")
                raise

    except Exception as e:
        logger.error(f"Error in summarize_large_text: {e}")
        return f"Error summarizing large text: {e}"

