# backend/web_scraper.py
import requests
from bs4 import BeautifulSoup
import pandas as pd
from .logger import logger

def scrape_url_content(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()  # Raise an exception for bad status codes
        soup = BeautifulSoup(response.content, 'html.parser')
        text_content = ""
        for element in soup.find_all(['p', 'h1', 'h2', 'h3', 'li']):
            text_content += element.get_text(separator='\n') + "\n"

        tables = pd.read_html(response.text) # Extracts all tables into a list of DataFrames
        return text_content, tables
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching URL {url}: {e}")
        return f"Error: Could not retrieve content from {url}"
    except pd.errors.EmptyDataError:
        logger.warning(f"No tables found on URL {url}")
        return text_content, []
    except Exception as e:
        logger.error(f"Error processing content from {url}: {e}")
        return f"Error: Could not process content from {url}"