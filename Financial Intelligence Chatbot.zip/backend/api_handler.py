# backend/api_handler.py
import os
import shutil
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import TextLoader, CSVLoader, PDFMinerLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain_openai import OpenAIEmbeddings, OpenAI
from dotenv import load_dotenv
import pandas as pd
from .logger import logger
from .table_query import plot_chart_from_prompt
from .summarizer import generate_summary
from .router import route_user_intent
from .rag_handler import reset_vector_db, create_vector_store_from_text, get_rag_response
from urllib.parse import urlparse
from .web_scraper import scrape_url_content
import tempfile
from .large_data_processor import summarize_large_text
from .table_analyzer import extract_columns, filter_data, sort_data, get_top_n, calculate_aggregate
from .history_manager import save_history
from .file_processor import process_file
from .language_handler import translate
from .file_processor import process_file
from langdetect import detect
import openai

session_context = {}
LARGE_TEXT_THRESHOLD = 10000


import os
import shutil
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import TextLoader, CSVLoader, PDFMinerLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain_openai import OpenAIEmbeddings, OpenAI
from dotenv import load_dotenv
import pandas as pd
from .logger import logger
from .table_query import plot_chart_from_prompt
from .summarizer import generate_summary
from .router import route_user_intent
from .rag_handler import reset_vector_db, create_vector_store_from_text, get_rag_response
from urllib.parse import urlparse
from .web_scraper import scrape_url_content
import tempfile
from .large_data_processor import summarize_large_text
from .table_analyzer import extract_columns, filter_data, sort_data, get_top_n, calculate_aggregate
from .history_manager import save_history
from .file_processor import process_file
from langdetect import detect
import openai

session_context = {}
LARGE_TEXT_THRESHOLD = 10000

def handle_user_query(user_input, uploaded_file, session_id, user_lang="en"):
    global session_context
    intent = "default"
    filepath = None
    content = None
    file_name = None
    extracted_tables = []
    query_url = None # Initialize query_url
    try:
        logger.info("Received query: %s", user_input)

        if session_id not in session_context:
            session_context[session_id] = {"last_processed_file": None, "vector_store_created": False, "raw_content": None} # Store raw content

        detected_lang = user_lang
        try:
            detected_lang = detect(user_input)
            logger.info(f"Detected language: {detected_lang}")
        except Exception as e:
            logger.warning(f"Error detecting language: {e}")

        if uploaded_file:
            if hasattr(uploaded_file, 'name'): # Check if it's a file object
                file_name = uploaded_file.name
                filepath = os.path.join("temp_files", file_name)
                os.makedirs("temp_files", exist_ok=True)
                with open(filepath, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                processed_data = process_file(filepath)
                if isinstance(processed_data, pd.DataFrame):
                    content = processed_data
                elif isinstance(processed_data, tuple):
                    content, extracted_tables = processed_data
                    session_context[session_id]["raw_content"] = content # Store raw text
                    if filepath.endswith(".pdf") or filepath.endswith(".docx"):
                        reset_vector_db(session_id)
                        create_vector_store_from_text(filepath, session_id)
                        session_context[session_id]["vector_store_created"] = True
                        content = "Processed document for RAG."
                elif isinstance(processed_data, str): # Error message from file processing
                    return processed_data
            else:
                query_url = uploaded_file # It's a URL string
        elif user_input.startswith("http") or user_input.startswith("https"):
            query_url = user_input

        if query_url:
            scraped_content = scrape_url_content(query_url)
            if isinstance(scraped_content, tuple):
                content, extracted_tables = scraped_content
                session_context[session_id]["raw_content"] = content # Store raw text
                reset_vector_db(session_id)
                if content and not content.startswith("Error"):
                    from langchain_community.document_loaders import WebBaseLoader
                    from langchain.text_splitter import RecursiveCharacterTextSplitter
                    from langchain_community.vectorstores import Chroma
                    from langchain_openai import OpenAIEmbeddings
                    loader = WebBaseLoader(query_url)
                    documents = loader.load()
                    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
                    texts = text_splitter.split_documents(documents)
                    embeddings = OpenAIEmbeddings(api_key=os.getenv("OPENAI_API_KEY"))
                    vectorstore = Chroma.from_documents(texts, embeddings)
                    session_context[session_id]["vector_store"] = vectorstore
                    content = "Web content processed for RAG."
                else:
                    return scraped_content
            else:
                return scraped_content # Error message from scraping

        # Re-evaluate intent after file processing
        try:
            intent = route_user_intent(user_input)
            logger.info(f"Classified user query as: {intent}")
        except Exception as e:
            logger.error(f"Error during intent routing: {e}")
            intent = "default"

        result = "Tool for this query not yet implemented or an error occurred during processing."

        if intent == "summarize":
            if session_context[session_id].get("raw_content"):
                result = generate_summary(session_context[session_id]["raw_content"])
            else:
                result = "Error: No content available for summarization."
        elif intent == "visualize":
            if isinstance(content, pd.DataFrame):
                result = plot_chart_from_prompt(content, user_input)
            elif extracted_tables:
                # Attempt to visualize the first extracted table
                result = plot_chart_from_prompt(extracted_tables[0], user_input)
            else:
                result = "Error: Visualization requires tabular data."
        elif intent == "rag":
            result = get_rag_response(user_input, session_id, content=content if isinstance(content, str) else None)
        elif intent == "table_query":
            processed_df = None
            if isinstance(content, pd.DataFrame):
                processed_df = content.copy()
            elif extracted_tables:
                processed_df = extracted_tables[0].copy() # Use the first extracted table

            if processed_df is not None:
                processed_df = filter_data(processed_df, user_input)
                processed_df = sort_data(processed_df, user_input)
                top_n_result = get_top_n(processed_df, user_input)
                aggregate_result = calculate_aggregate(processed_df, user_input)
                relevant_cols = extract_columns(processed_df, user_input)

                output_parts = []
                if not top_n_result.empty and not top_n_result.equals(processed_df.head(5)):
                    output_parts.append(f"Top/Bottom Results:\n{top_n_result[relevant_cols].to_string()}")
                elif not processed_df.empty:
                    output_parts.append(f"Processed Data (first 5 rows):\n{processed_df[relevant_cols].head().to_string()}")
                elif relevant_cols:
                    output_parts.append(f"Identified relevant columns: {', '.join(relevant_cols)}. No data matches filter or top/bottom criteria (if any).")
                else:
                    output_parts.append("Could not identify relevant columns or process the data based on your query.")

                if aggregate_result and aggregate_result != "Could not find any aggregate calculations to perform based on your query.":
                    output_parts.append(f"\nAggregations:\n{aggregate_result}")

                result = "\n\n".join(output_parts)
            else:
                    result = "Error: Table query requires tabular data."

        if user_lang != "en" and detected_lang != user_lang:
            result = translate(result, user_lang)

        save_history(session_id, user_input, result, file_name)

        if filepath and os.path.exists(filepath) and not urlparse(filepath).scheme:
            try:
                os.remove(filepath)
                logger.info(f"Deleted temporary file: {filepath}")
            except Exception as e:
                logger.error(f"Error deleting temporary file {filepath}: {e}")

        return result

    except Exception as e:
        logger.exception("Error handling query")
        return f"An error occurred: {str(e)}"