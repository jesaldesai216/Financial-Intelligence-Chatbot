# backend/table_analyzer.py

import pandas as pd
import re
from .logger import logger

def extract_columns(df, query):
    """
    Identifies relevant columns in a DataFrame based on a user query.
    """
    query = query.lower()
    relevant_columns = []
    for col in df.columns:
        col_lower = col.lower()
        if col_lower in query or any(word in query for word in col_lower.split()):
            relevant_columns.append(col)
        elif re.search(r'\b' + re.escape(col_lower) + r'\b', query): # Match whole words
            relevant_columns.append(col)
    logger.info(f"Extracted relevant columns '{relevant_columns}' for query: '{query}'")
    return relevant_columns

def filter_data(df, query):
    """
    Attempts to filter a DataFrame based on conditions in the user query.
    """
    logger.info(f"Attempting to filter data for query: '{query}'")
    filtered_df = df.copy()
    query = query.lower()

    for col in df.columns:
        col_lower = col.lower()

        # Equality check
        match = re.search(rf'{col_lower}\s*=\s*(\w+)', query)
        if match:
            value = match.group(1)
            try:
                if pd.api.types.is_numeric_dtype(df[col]):
                    value_converted = pd.to_numeric(value)
                    filtered_df = filtered_df[filtered_df[col] == value_converted]
                    logger.info(f"Applied filter: {col} == {value_converted} (numeric)")
                else:
                    filtered_df = filtered_df[filtered_df[col].astype(str).str.lower() == value]
                    logger.info(f"Applied filter: {col} == '{value}' (string)")
            except ValueError:
                logger.warning(f"Could not convert value '{value}' for column '{col}'. Skipping equality filter.")

        # Greater than check
        match_gt = re.search(rf'{col_lower}\s*>(?!=)\s*(\d+)', query)
        if match_gt and pd.api.types.is_numeric_dtype(df[col]):
            value = pd.to_numeric(match_gt.group(1))
            filtered_df = filtered_df[filtered_df[col] > value]
            logger.info(f"Applied filter: {col} > {value}")

        # Less than check
        match_lt = re.search(rf'{col_lower}\s*<(?!=)\s*(\d+)', query)
        if match_lt and pd.api.types.is_numeric_dtype(df[col]):
            value = pd.to_numeric(match_lt.group(1))
            filtered_df = filtered_df[filtered_df[col] < value]
            logger.info(f"Applied filter: {col} < {value}")

    if filtered_df.equals(df):
        logger.info("No filters applied.")
        return df
    else:
        logger.info(f"Filtered DataFrame shape: {filtered_df.shape}")
        return filtered_df

def sort_data(df, query):
    """
    Attempts to sort a DataFrame based on a column mentioned in the user query.
    """
    logger.info(f"Attempting to sort data for query: '{query}'")
    query = query.lower()
    sort_keys = []
    ascending = True

    # Look for keywords indicating sorting
    sort_match = re.search(r'sort\s+by\s+(\w+)', query)
    if not sort_match:
        sort_match = re.search(r'order\s+by\s+(\w+)', query)

    if sort_match:
        sort_column_lower = sort_match.group(1)
        for col in df.columns:
            if col.lower() == sort_column_lower:
                sort_keys.append(col)
                break

        # Check for descending order
        if re.search(r'descending|desc', query):
            ascending = False

    if sort_keys:
        try:
            sorted_df = df.sort_values(by=sort_keys, ascending=ascending)
            logger.info(f"Sorted DataFrame by '{sort_keys}' (ascending={ascending})")
            return sorted_df
        except KeyError as e:
            logger.warning(f"Column(s) '{sort_keys}' not found in DataFrame for sorting.")
            return df
    else:
        logger.info("No sorting criteria found in the query.")
        return df

def get_top_n(df, query, n=5):
    """
    Attempts to extract the top N rows from a DataFrame based on a column in the query.
    """
    logger.info(f"Attempting to get top {n} rows for query: '{query}'")
    query = query.lower()
    top_n_col = None
    ascending = False  # Default to top (highest value)

    top_match = re.search(r'top\s+(\d+)\s+([\w\s]+)\s+by\s+(\w+)', query)
    if not top_match:
        top_match = re.search(r'bottom\s+(\d+)\s+([\w\s]+)\s+by\s+(\w+)', query)
        if top_match:
            ascending = True
            n = int(top_match.group(1))
            subject = top_match.group(2).strip() # Not directly used yet
            sort_column_lower = top_match.group(3).lower()
        else:
            top_match = re.search(r'top\s+(\w+)\s+by\s+(\w+)', query)
            if top_match:
                try:
                    n = int(top_match.group(1))
                except ValueError:
                    n = 5 # Default if 'top' is not followed by a number
                subject = "" # Not directly used yet
                sort_column_lower = top_match.group(2).lower()
            else:
                return df.head(n) # If no explicit top N request, just return the head

    if top_match:
        sort_column_lower = top_match.group(top_match.re.groups - (1 if ascending else 0)) # Adjust group index
        for col in df.columns:
            if col.lower() == sort_column_lower:
                top_n_col = col
                break

        if top_n_col and pd.api.types.is_numeric_dtype(df[top_n_col]):
            sorted_df = df.sort_values(by=top_n_col, ascending=ascending)
            logger.info(f"Retrieved top {n} by '{top_n_col}' (ascending={ascending})")
            return sorted_df.head(n)
        elif top_n_col:
            logger.warning(f"Cannot get top N by non-numeric column: '{top_n_col}'.")
            return df.head(n)
        else:
            logger.warning(f"Sort column not found for top N query.")
            return df.head(n)
    else:
        return df.head(n)

def calculate_aggregate(df, query):
    """
    Attempts to calculate aggregate statistics (sum, average, min, max, count)
    based on the user query.
    """
    logger.info(f"Attempting to calculate aggregate for query: '{query}'")
    query = query.lower()
    aggregate_funcs = {
        'sum': 'sum',
        'total': 'sum',
        'average': 'mean',
        'avg': 'mean',
        'mean': 'mean',
        'minimum': 'min',
        'min': 'min',
        'maximum': 'max',
        'max': 'max',
        'count': 'count',
        'number of': 'count'
    }
    results = {}

    for agg_keyword, agg_func in aggregate_funcs.items():
        agg_match = re.search(rf'(?:{agg_keyword})\s+of\s+(\w+)', query)
        if agg_match:
            column_lower = agg_match.group(1)
            for col in df.columns:
                if col.lower() == column_lower and pd.api.types.is_numeric_dtype(df[col]):
                    try:
                        if agg_func == 'count':
                            results[f"{agg_keyword} of {col}"] = df[col].count()
                        else:
                            results[f"{agg_keyword} of {col}"] = df[col].agg(agg_func)
                        logger.info(f"Calculated {agg_func} for column '{col}'.")
                    except Exception as e:
                        logger.error(f"Error calculating {agg_func} for column '{col}': {e}")
                    break
                elif col.lower() == column_lower:
                    logger.warning(f"Cannot calculate {agg_keyword} on non-numeric column: '{col}'.")

    if results:
        return "\n".join([f"{key}: {value}" for key, value in results.items()])
    else:
        return "Could not find any aggregate calculations to perform based on your query."


def analyze_trends(df, query):
    """
    Attempts to identify and analyze basic trends in the DataFrame.
    This is a very basic implementation and needs significant improvement
    for real-world trend analysis.
    """
    logger.info(f"Attempting to analyze trends for query: '{query}'")
    query = query.lower()
    date_cols = []
    numeric_cols = []

    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            date_cols.append(col)
        elif pd.api.types.is_numeric_dtype(df[col]):
            numeric_cols.append(col)

    if not date_cols or not numeric_cols:
        return "Could not identify date and numeric columns for trend analysis."

    # Basic trend: looking for "trend of [numeric] over [date]"
    trend_match = re.search(r'trend\s+of\s+(\w+)\s+over\s+(\w+)', query)
    if trend_match:
        numeric_col_lower = trend_match.group(1)
        date_col_lower = trend_match