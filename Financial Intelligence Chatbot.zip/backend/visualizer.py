import pandas as pd
import matplotlib.pyplot as plt
import os
import uuid
from .logger import logger

def generate_plot(df, x_col, y_col):
    try:
        plot_id = str(uuid.uuid4())
        file_path = f"temp_files/{plot_id}.png"
        df.plot(x=x_col, y=y_col, kind='line')
        plt.title(f"{y_col} over {x_col}")
        plt.tight_layout()
        plt.savefig(file_path)
        plt.close()
        return file_path
    except Exception as e:
        logger.exception("Failed to generate plot")
        return None
