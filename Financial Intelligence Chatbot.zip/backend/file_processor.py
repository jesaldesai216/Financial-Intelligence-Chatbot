# backend/file_processor.py
import pandas as pd
import io
from docx import Document
from pdfminer.high_level import extract_text
import camelot
from .logger import logger

def process_csv(file_path):
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        logger.error(f"Error reading CSV file {file_path}: {e}")
        return None

def process_excel(file_path):
    try:
        return pd.read_excel(file_path)
    except Exception as e:
        logger.error(f"Error reading Excel file {file_path}: {e}")
        return None

def process_pdf(file_path):
    text = ""
    tables = []
    try:
        text = extract_text(file_path)
        try:
            pdf_tables = camelot.read_pdf(file_path)
            for table in pdf_tables:
                tables.append(table.df)
        except Exception as e:
            logger.warning(f"Error extracting tables from PDF {file_path}: {e}")
    except Exception as e:
        logger.error(f"Error reading PDF file {file_path}: {e}")
    return text, tables

def process_docx(file_path):
    text = ""
    tables = []
    try:
        document = Document(file_path)
        for paragraph in document.paragraphs:
            text += paragraph.text + "\n"
        for table in document.tables:
            df = [['' for _ in range(len(table.columns))] for _ in range(len(table.rows))]
            for i, row in enumerate(table.rows):
                for j, cell in enumerate(row.cells):
                    df[i][j] = cell.text
            tables.append(pd.DataFrame(df))
    except Exception as e:
        logger.error(f"Error reading DOCX file {file_path}: {e}")
    return text, tables

def process_link(url):
    # This functionality is moved to web_scraper.py
    pass

def process_file(file_path):
    if file_path.endswith(".csv"):
        return process_csv(file_path)
    elif file_path.endswith(".xlsx"):
        return process_excel(file_path)
    elif file_path.endswith(".pdf"):
        text, tables = process_pdf(file_path)
        return text, tables
    elif file_path.endswith(".docx"):
        text, tables = process_docx(file_path)
        return text, tables
    elif file_path.startswith("http") or file_path.startswith("https"):
        # Handled in api_handler to use web_scraper
        return file_path
    return None