from langdetect import detect
from deep_translator import GoogleTranslator
from .logger import logger

def detect_language(text):
    try:
        lang = detect(text)
        logger.info("Detected language: %s", lang)
        return lang
    except Exception as e:
        logger.exception("Language detection failed")
        return "en"

def translate(text, target_lang):
    try:
        translated_text = GoogleTranslator(source='auto', target=target_lang).translate(text)
        logger.info("Translated text to %s: %s", target_lang, translated_text)
        return translated_text
    except Exception as e:
        logger.exception("Translation failed")
        return text  # fallback: return original if translation fails
