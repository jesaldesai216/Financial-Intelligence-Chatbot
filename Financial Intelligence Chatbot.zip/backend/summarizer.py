from openai import OpenAI
from .logger import logger
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=api_key)

def generate_summary(content):
    try:
        if isinstance(content, str):
            text_to_summarize = content
        elif hasattr(content, 'to_string'):  # Check if it's a DataFrame
            text_to_summarize = content.to_string()
        else:
            return "Error: Could not process content for summarization."

        prompt = f"""Please provide a concise summary of the following financial document:

        {text_to_summarize}

        Summary:"""

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # You can choose a different model
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,  # Adjust for desired level of creativity
        )

        summary = response.choices[0].message.content.strip()
        logger.info(f"Generated summary: {summary}")
        return summary

    except openai.error.RateLimitError as e:
        logger.error(f"OpenAI Rate Limit Exceeded: {e}")
        return "Error: The model's token limit was exceeded. Please try a shorter query or provide less data for summarization."
    except Exception as e:
        logger.exception("Error during summarization")
        return f"Error: Failed to generate summary - {str(e)}"