# rag_handler.py
import os
import shutil
import openai
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import TextLoader, CSVLoader, PDFMinerLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain_openai import OpenAIEmbeddings, OpenAI
from dotenv import load_dotenv
import pandas as pd  # Import pandas
from .logger import logger  # Import your logger

# Directory to store vector DB (now session-specific)
VECTOR_BASE_DIR = "vector_store"

# Load environment variables
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")

# Handle missing API key
if not openai_api_key:
    raise EnvironmentError("Missing OPENAI_API_KEY in your environment variables")

# Initialize OpenAI Embeddings client
embeddings = OpenAIEmbeddings(api_key=openai_api_key)
llm = OpenAI(api_key=openai_api_key)

def get_vector_dir(session_id):
    return os.path.join(VECTOR_BASE_DIR, session_id)

def reset_vector_db(session_id):
    vector_dir = get_vector_dir(session_id)
    try:
        if os.path.exists(vector_dir):
            shutil.rmtree(vector_dir)
            logger.info(f"Deleted vector store directory for session {session_id}: {vector_dir}")
        else:
            logger.info(f"No vector store directory found for session {session_id} at {vector_dir}")
    except Exception as e:
        logger.error(f"Error deleting vector store directory for session {session_id}: {e}")

def extract_text_from_file(file_path):
    logger.info(f"Attempting to read file in extract_text_from_file: {file_path}")  # Log the path

    if file_path.endswith(".csv"):
        try:
            df = pd.read_csv(file_path)
            text = df.to_string()
            return [text]
        except Exception as e:
            raise Exception(f"Error reading CSV file: {e}")
    elif file_path.endswith(".xlsx"):
        try:
            df = pd.read_excel(file_path)
            text = df.to_string()
            return [text]
        except Exception as e:
            raise Exception(f"Error reading Excel file: {e}")
    elif file_path.endswith(".pdf"):
        try:
            from PyPDF2 import PdfReader
            text = ""
            with open(file_path, 'rb') as f:
                reader = PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            return [text]
        except Exception as e:
            raise Exception(f"Error reading PDF file: {e}")
    elif file_path.endswith(".docx"):
        try:
            from docx import Document
            text = ""
            document = Document(file_path)
            for paragraph in document.paragraphs:
                text += paragraph.text + "\n"
            return [text]
        except Exception as e:
            raise Exception(f"Error reading DOCX file: {e}")
    else:
        raise ValueError(f"Unsupported file format: {file_path}")

def create_vector_store_from_text(file_path, session_id):
    """Create a Chroma vector store from a document file using OpenAI embeddings."""
    try:
        text_chunks = extract_text_from_file(file_path)
        vector_dir = get_vector_dir(session_id)
        os.makedirs(vector_dir, exist_ok=True)
        vectorstore = Chroma.from_texts(
            texts=text_chunks,
            embedding=embeddings,
            persist_directory=vector_dir
        )
        vectorstore.persist()
        return vectorstore
    except Exception as e:
        logger.error(f"Error creating vector store: {e}")
        return None

def load_vector_store(session_id):
    """Load the persisted Chroma vector store for a specific session."""
    vector_dir = get_vector_dir(session_id)
    if not os.path.exists(vector_dir):
        return None
    try:
        return Chroma(persist_directory=vector_dir, embedding_function=embeddings)
    except Exception as e:
        logger.error(f"Error loading vector store: {e}")
        return None

def get_rag_response(prompt, session_id, content=None):
    """Generate a RAG-based answer using OpenAI LLM and vector search for a specific session."""
    try:
        if content:
            text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
            texts = text_splitter.split_text(content)
            # In-memory vector store for URL content
            docsearch = Chroma.from_texts(texts, embeddings)
            retriever = docsearch.as_retriever(search_type="similarity", search_kwargs={"k": 4})
            qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
            return qa_chain.run(prompt)
        else:
            # Use persisted vector store for uploaded files
            vectorstore = load_vector_store(session_id)
            if not vectorstore:
                return "Error: No vector data found. Please upload a document first."
            retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 4})
            qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
            return qa_chain.run(prompt)
    except openai.RateLimitError as e:  # Catch directly from openai
        logger.error(f"OpenAI Rate Limit Exceeded during RAG: {e}")
        return "Error: The language model for answering questions is currently overloaded. Please try your question again later or try a shorter query."
    except Exception as e:
        logger.error(f"Error during RAG response generation: {e}")
        return f"Error: Could not generate an answer based on the document. Please try again or rephrase your question."