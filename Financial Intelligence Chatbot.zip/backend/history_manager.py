import os
import json
from datetime import datetime
from sqlalchemy import create_engine, Column, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import uuid

DATABASE_URL = "sqlite:///chat_history.db"
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
Base = declarative_base()

class ChatHistory(Base):
    __tablename__ = 'chat_history'
    id = Column(String, primary_key=True)
    session_id = Column(String)
    query = Column(Text)
    response = Column(Text)
    file_name = Column(String)
    timestamp = Column(DateTime)

Base.metadata.create_all(engine)

def save_history(session_id, query, response, file_name):
    db = Session()
    entry = ChatHistory(
        id=str(uuid.uuid4()),
        session_id=session_id,
        query=query,
        response=response,
        file_name=file_name,
        timestamp=datetime.now()
    )
    db.add(entry)
    db.commit()
    db.close()

def get_history(session_id):
    db = Session()
    history = db.query(ChatHistory).filter(ChatHistory.session_id == session_id).all()
    db.close()
    return history

def get_all_history():
    db = Session()
    all_data = db.query(ChatHistory).all()
    db.close()
    return all_data

def clear_history():
    db = Session()
    db.query(ChatHistory).delete()
    db.commit()
    db.close()